import { LinkMode } from '../../../../common/ethernet';

interface SupportedLinkModes {
    duplex: string;
    speed: number;
}

interface DeviceInfoData {
    ipreadonly: boolean;
    label: string;
    name: string;
    autonegsupported: boolean;
    supportedlinkmodes: SupportedLinkModes[];
    type: string;
}

export default function getSupportedLinkModes(value: string | Error) {
    const naturalSort = require('typescript-natural-sort');
    const ethernetBaseId = 'networking.ethernet.interfaces';

    if (value instanceof Error) {
        return {
            'networking.ethernet.interfaces.0.supportedlinkmodes': value,
            'networking.ethernet.interfaces.0.autonegsupported': value
        }
    }

    var data = <DeviceInfoData[]>JSON.parse(value);
    var sortedData = data.sort((a, b) => naturalSort(a.name, b.name));

    const result = {} as any;
    sortedData.forEach((entry, index) => {
        let modes = entry.supportedlinkmodes.map(mode => LinkMode.toString(
            { speed: mode.speed, duplex: mode.duplex.toLowerCase() } as LinkMode));
        result[`${ethernetBaseId}.${index}.supportedlinkmodes`] = modes;
        result[`${ethernetBaseId}.${index}.autonegsupported`] = entry.autonegsupported;
    });
    return result;
}