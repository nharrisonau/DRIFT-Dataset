import { createBridgeLabel, getBridgeIndex, sortWithPriority } from "../../../../ethernet-component/bridge-config";
import { IpConfiguration } from "../../../../ethernet-component/config";

export default function getIpConfig(value: string | Error) {
    const tcpIpBaseId = 'networking.tcpip.interfaces';
    if (value instanceof Error) {
        return {
            [`${tcpIpBaseId}.0.label`]: value,
            [`${tcpIpBaseId}.0.name`]: value,
            [`${tcpIpBaseId}.0.source`]: value,
            [`${tcpIpBaseId}.0.static.ipaddress`]: value,
            [`${tcpIpBaseId}.0.static.subnetmask`]: value,
            [`${tcpIpBaseId}.0.static.gatewayindex`]: value,
            [`${tcpIpBaseId}.0.static.gatewaynumber`]: value
        }
    }

    const result = {} as any;
    const tcpipSettings = JSON.parse(value) as IpConfiguration;

    Object.keys(tcpipSettings).sort(sortWithPriority).forEach((bridgeName, index) => {
        let bridgeSettings = tcpipSettings[bridgeName];
        let bridgeIndex = getBridgeIndex(bridgeName);
        if (!bridgeIndex)
            bridgeIndex = 0;
        result[`${tcpIpBaseId}.${index}.label`] = createBridgeLabel(bridgeName);
        result[`${tcpIpBaseId}.${index}.name`] = bridgeName;
        result[`${tcpIpBaseId}.${index}.source`] = bridgeSettings.source;
        result[`${tcpIpBaseId}.${index}.static.ipaddress`] = bridgeSettings.ipaddr;
        result[`${tcpIpBaseId}.${index}.static.subnetmask`] = bridgeSettings.netmask;
        result[`${tcpIpBaseId}.${index}.static.gatewayindex`] = String(bridgeIndex);
        result[`${tcpIpBaseId}.${index}.static.gatewaynumber`] = String(bridgeIndex + 1);
    });
    return result;
};