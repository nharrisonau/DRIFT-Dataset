export default function (value: string|Error) {
    
    const baseId = 'networking.tcpip.dhcp.dnsserver';
    if (value instanceof Error) {    
        return {
            [`${baseId}.0.ipaddress`]: value,
            [`${baseId}.0.index`]: value,
            [`${baseId}.noentry`]: value
        }
    }

    let returnResult = {} as any;
            
    if (value === '') {
        return{
            [`${baseId}.noentry`]: 'none'
        };
    }

    const ipAddresses = value.split('\t');
    if (ipAddresses.length > 0) {
        returnResult = ipAddresses.reduce((result: any, ipAddress, index) => {
            result[`${baseId}.${index}.ipaddress`] = ipAddress;
            result[`${baseId}.${index}.index`] = index + 1;
            return result;
        }, {} as any);

        returnResult[`${baseId}.noentry`] = 'elements exists';
    }
    
    return returnResult;
};