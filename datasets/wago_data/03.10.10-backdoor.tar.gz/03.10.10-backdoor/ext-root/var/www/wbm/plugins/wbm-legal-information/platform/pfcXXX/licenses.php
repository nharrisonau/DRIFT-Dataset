<?php 

header('Content-Type: application/json; charset=utf-8');
include_once './licenses.inc.php';

$loader = new LicensesLoader('/var/www/wbm/licenses');

$requestBody = json_decode(file_get_contents('php://input'), true);
// Check for correct content type only if a body is set
if(!empty($requestBody))
{
    // Get headers content type information
    $content_type = explode(";",$_SERVER["CONTENT_TYPE"]);
    $return_value = (stripos($content_type[0],'application/json') !== false);
    // If content type is JSON look through additional arguments if charset is given and
    // check if it is set to utf-8
    if(    $return_value 
        && count($content_type) > 1)
    {
        foreach($content_type as $value)
        {
            $current_entry = explode("=",$value);
            if(   (count($current_entry) > 1)
                && (strcasecmp(trim($current_entry[0]),'charset') === 0))
            {
                $return_value = (strcasecmp($current_entry[1],'utf-8') === 0);
            }
        }
    }
    if($return_value)
    {
        http_response_code(200);
    }
    else
    {
        http_response_code(415);
        return "{}";
    }
}
$packageId = ($requestBody && isset($requestBody['package'])) ? $requestBody['package'] : '';

$extension = end(explode(".", $packageId));


if (isset($packageId) && $packageId) {

    $package = $loader->getOSSPackageForPackageId($packageId);
    $license = $loader->getOSSPackageLicense($package);

    $response = json_encode((object) [
        'package' => $package,
        'license' => $license
    ]);
    echo $response;
} 
else {

    $wago = $loader->getWagoLicenseAgreement();
    $trades = $loader->getTrademarksList();
    $oss = $loader->getOSSDisclaimer();
    $list = $loader->getOSSPackageList();
    
    $response = json_encode((object) [
        'wagoSoftwareLicenseAgreement' => $wago,
        'trademarksList' => $trades,
        'ossDisclaimer' => $oss,
        'ossPackages' => $list
    ]);
    echo $response;
}
