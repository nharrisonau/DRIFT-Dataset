<?php
    if($_SERVER['REQUEST_METHOD'] === 'GET')
    {
        $output = array(
            "restoreStatus" => shell_exec('sudo /etc/config-tools/firmware_restore_status --quiet')
        );
        if(    ($output["restoreStatus"] === false)
            || ($output["restoreStatus"] === null))
        {
             error_log('Error during read of firmware restore status');
             $output["restoreStatus"] = null;
        }
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($output);
    }
    else
    {
        http_response_code(405); // 405 Method Not Allowed
    }
?>
