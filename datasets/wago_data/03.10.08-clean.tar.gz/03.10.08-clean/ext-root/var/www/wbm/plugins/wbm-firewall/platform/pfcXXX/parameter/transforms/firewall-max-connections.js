/*!
 * @wago/wbm-firewall@1.6.3
 * 
 *   Copyright © 2022 WAGO GmbH & Co. KG
 * 
 *   License: 
 *     WAGO Software License Agreement
 * 
 *   Contributors:
 *     
 * 
 *   Description:
 *     Firewall Settings
 * 
 *   
 */
this["/firewall-max-connections"]=function(e){var t={};function n(i){if(t[i])return t[i].exports;var r=t[i]={i:i,l:!1,exports:{}};return e[i].call(r.exports,r,r.exports,n),r.l=!0,r.exports}return n.m=e,n.c=t,n.d=function(e,t,i){n.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:i})},n.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},n.t=function(e,t){if(1&t&&(e=n(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var i=Object.create(null);if(n.r(i),Object.defineProperty(i,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var r in e)n.d(i,r,function(t){return e[t]}.bind(null,r));return i},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="",n(n.s=4)}({4:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=function(e){var t={tcpLimitValueUnit:"-",udpLimitValueUnit:"-"};return void 0!==typeof e["firewall.connectionlimit.tcp.value"]&&e["firewall.connectionlimit.tcp.value"].length>0&&(t.tcpLimitValueUnit=e["firewall.connectionlimit.tcp.value"]+"/second"),void 0!==typeof e["firewall.connectionlimit.udp.value"]&&e["firewall.connectionlimit.udp.value"].length>0&&(t.udpLimitValueUnit=e["firewall.connectionlimit.udp.value"]+"/second"),t}}}).default;
//# sourceMappingURL=firewall-max-connections.js.map