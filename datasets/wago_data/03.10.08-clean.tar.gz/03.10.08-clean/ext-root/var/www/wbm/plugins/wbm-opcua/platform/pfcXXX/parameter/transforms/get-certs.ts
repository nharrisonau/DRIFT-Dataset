interface RawJson {
    [category: string]: []
}

export default function(raw: string | Error, paramIdType: string, type: string) {
    if (raw instanceof Error) {
        const paramId = `${paramIdType}.certificates.${type}.*.name`;
        return {
            paramId: raw,
        };
    }

    const json = JSON.parse(raw) as RawJson;
    let certs: string[] = [];
    if (type == 'own') {
        certs = json.own || [];
    }
    else if (type == 'trusted') {
        certs = json.trusted || [];
    }
    else if (type == 'rejected') {
        certs = json.rejected || [];
    }
    else if (type == 'keys') {
        certs = json.keys || [];
    }

    const results: {[paramId: string]: any} = {};
    certs.forEach((key, index) => {
        results[`${paramIdType}.certificates.${type}.${index}.name`] = key;
    });

    return results;
}
