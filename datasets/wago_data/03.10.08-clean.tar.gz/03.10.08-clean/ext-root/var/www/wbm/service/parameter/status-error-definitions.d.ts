export declare const parameterServiceStatusErrorDefinitions: [number, string][];
