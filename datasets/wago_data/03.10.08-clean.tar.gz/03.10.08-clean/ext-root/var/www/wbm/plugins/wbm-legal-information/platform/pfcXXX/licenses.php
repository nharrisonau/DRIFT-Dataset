<?php 

include_once './licenses.inc.php';

$loader = new LicensesLoader('/var/www/wbm/licenses');

$requestBody = json_decode(file_get_contents('php://input'), true);
$packageId = $requestBody['package'];

$extension = end(explode(".", $packageId));


if (isset($packageId)) {

    $package = $loader->getOSSPackageForPackageId($packageId);
    $license = $loader->getOSSPackageLicense($package);

    if ($license == false) {
        $license = shell_exec("xz -cd /var/www/wbm/licenses/oss/{$packageId}.txt.xz");
    }

    $response = json_encode((object) [
        'package' => $package,
        'license' => $license
    ]);
    echo $response;
} 
else {

    $wago = $loader->getWagoLicenseAgreement();
    $trades = $loader->getTrademarksList();
    $oss = $loader->getOSSDisclaimer();
    $list = $loader->getOSSPackageList();
    
    $response = json_encode((object) [
        'wagoSoftwareLicenseAgreement' => $wago,
        'trademarksList' => $trades,
        'ossDisclaimer' => $oss,
        'ossPackages' => $list
    ]);
    echo $response;
}