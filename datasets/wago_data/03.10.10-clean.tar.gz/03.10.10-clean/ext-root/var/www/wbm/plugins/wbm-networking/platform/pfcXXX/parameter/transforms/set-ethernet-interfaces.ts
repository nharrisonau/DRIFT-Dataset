import { Parameters } from "../../../../common/utils";
import { LinkState, MacLearning, Autonegotiation, Duplex, LinkMode } from "../../../../common/ethernet";

interface CommandParameters {
    state: LinkState
    maclearning: MacLearning
    autonegotiation: Autonegotiation
    duplex: Duplex
    speed: number
}

export default function convertParameters(parameters: Parameters) {
    return Object.keys(parameters)
        .reduce((command, id) => {
            const value = parameters[id];
            const property = getProperty(id);
    
            if (property == 'state') {
                command.state = LinkState.fromBoolean(value);
            } else if (property == 'maclearning') {
                command.maclearning =  MacLearning.fromBoolean(value);
            } else if (property == 'speedduplex') {
                if (value === 'autonegotiation') {
                    command.autonegotiation = Autonegotiation.on;
                    command.speed = 0;
                    command.duplex = Duplex.unknown;
                } else {
                    const linkMode = LinkMode.fromString(value);
                    command.autonegotiation = Autonegotiation.off;
                    command.speed = linkMode.speed;
                    command.duplex = linkMode.duplex;
                }
            }
            return command
        }, {} as CommandParameters)
}

function getProperty(parameterId: string): string {
    const idParts = parameterId.split('.');
    return idParts[idParts.length - 1];
}