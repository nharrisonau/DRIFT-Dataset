import { LinkMode } from '../../../../common/ethernet';

const naturalSort = require('typescript-natural-sort');
const baseId = 'networking.ethernet.interfaces';

interface InterfaceConfiguration {
    device: string;
    state: string;
    maclearning: string;
    autonegotiation: string;
    speed: number;
    duplex: string;
}

export default function getEthInterfaces(value: string | Error) {
    if (value instanceof Error) {
        return {
            'networking.ethernet.interfaces.0.label': value,
            'networking.ethernet.interfaces.0.state': value,
            'networking.ethernet.interfaces.0.maclearning': value,
            'networking.ethernet.interfaces.0.speedduplex': value
        }
    }

    return (<InterfaceConfiguration[]>JSON.parse(value))
        .sort((a, b) => naturalSort(a.device, b.device))
        .reduce((p, c, i) => {
            p[`${baseId}.${i}.label`] = c.device;
            p[`${baseId}.${i}.state`] = c.state === "up";
            p[`${baseId}.${i}.maclearning`] = c.maclearning === "on" || c.maclearning === "unknown";
            p[`${baseId}.${i}.speedduplex`] = c.autonegotiation === 'on'
                ? 'autonegotiation' : LinkMode.toString({ speed: c.speed, duplex: c.duplex } as LinkMode);
            return p
        }, {} as any)
}