import { Parameters } from "../../../../common/utils";

type GatewayParameters = {
    'state': string
    'gateway': string
}

export default function setDefaultGateway (parameters: Parameters) {
    const commandParameters = {} as GatewayParameters;

    for (const parameterId of Object.keys(parameters)) {
        const parameterValue = parameters[parameterId];
        const idParts = parameterId.split('.');
        const property = idParts[idParts.length - 1];

        switch (property) {
            case 'gateway':
                const gateway = parameterValue;
                commandParameters.state = gateway !== "" ? "enabled" : "disabled";
                commandParameters.gateway = gateway === "" ? "0.0.0.0" : gateway ;
                break;

            default:
                break;
        }
    }
    return commandParameters;
}