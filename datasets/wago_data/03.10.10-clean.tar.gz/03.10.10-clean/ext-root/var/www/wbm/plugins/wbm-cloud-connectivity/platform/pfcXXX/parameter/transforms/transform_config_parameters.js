/*!
 * @wago/wbm-cloud-connectivity@1.12.5
 * 
 *   Copyright © 2022 WAGO GmbH & Co. KG
 * 
 *   License: 
 *     WAGO Software License Agreement
 * 
 *   Contributors:
 *     
 * 
 *   Description:
 *     Plugin for WBM-NG to configure and monitor Cloud Connectivity
 * 
 *   
 */
this["/transform_config_parameters"]=function(e){var t={};function c(o){if(t[o])return t[o].exports;var r=t[o]={i:o,l:!1,exports:{}};return e[o].call(r.exports,r,r.exports,c),r.l=!0,r.exports}return c.m=e,c.c=t,c.d=function(e,t,o){c.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:o})},c.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},c.t=function(e,t){if(1&t&&(e=c(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var o=Object.create(null);if(c.r(o),Object.defineProperty(o,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var r in e)c.d(o,r,function(t){return e[t]}.bind(null,r));return o},c.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return c.d(t,"a",t),t},c.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},c.p="",c(c.s=0)}([function(e,t,c){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=function(e){var t=$("#idOfTheSelectedConnection"),c="Connection"+t.val(),o=JSON.parse(e),r={};r["cc.cloudconnectionid"]=t.val(),r["cc.keepaliveinterval"]=o[c].KeepAliveInterval,r["cc.connectionenabled"]="true"==o[c].Enabled,r["cc.cloud"]=o[c].CloudType,r["cc.hostname"]=o[c].Host,r["cc.clientid"]=o[c].ClientId,r["cc.password"]=o[c].Password,r["cc.username"]=o[c].User,r["cc.enablewebsockets"]="MQTToverWS"==o[c].TransportProtocol,r["cc.enablecompression"]="GzipDefault"==o[c].Compression,r["cc.dataprotocol"]=o[c].MessagingProtocol,r["cc.cachemode"]=o[c].CacheMode,r["cc.cleansession"]="true"==o[c].CleanSession,r["cc.enabletls"]="true"==o[c].UseTLS,r["cc.portnumber"]=o[c].Port,r["cc.rootcafile"]=o[c].CaFile,r["cc.certfile"]=o[c].CertFile,r["cc.keyfile"]=o[c].KeyFile,r["cc.deviceinfo"]="true"==o[c].SendDeviceInfo,r["cc.devicestatus"]="true"==o[c].SendDeviceStatus,r["cc.standardcommands"]="true"==o[c].StandardCommandsEnabled,r["cc.lastwill"]="true"==o[c].LastWillEnabled,r["cc.lastwilltopic"]=o[c].LastWillTopic,r["cc.lastwillpayload"]=o[c].LastWillPayload,r["cc.lastwillqos"]=o[c].LastWillQoS,r["cc.lastwillretain"]="true"==o[c].LastWillRetain,r["cc.authentication"]=o[c].AuthenticationMethod,r["cc.messageproperty"]=o[c].MessageProperty,r["cc.proxytype"]=o[c].ProxyType,r["cc.httpproxyhost"]=o[c].HttpProxyHost,r["cc.httpproxyport"]=o[c].HttpProxyPort,r["cc.httpproxyuser"]=o[c].HttpProxyUser,r["cc.httpproxypassword"]=o[c].HttpProxyPassword;var n="#sub-menu-item-ccconnection"+t.val();$(n+" #theMassStorageIsReady").remove();var a=$('<input type="hidden" />');return a.attr("id","theMassStorageIsReady"),a.val(o[c].NonVolatileStorageIsAvailable),$(n).append(a),r}}]).default;
//# sourceMappingURL=transform_config_parameters.js.map