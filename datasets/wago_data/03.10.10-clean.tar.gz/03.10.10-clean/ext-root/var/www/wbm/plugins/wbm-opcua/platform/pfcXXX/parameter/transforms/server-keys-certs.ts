import getCerts from './get-certs'

export default function(raw: string | Error) {
    return getCerts(raw, 'opcuaserver', 'keys');
}