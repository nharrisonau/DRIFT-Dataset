import { Base } from "wbm-base/base";
declare const _default: (base: Base) => Promise<void>;
export default _default;
